package com.tnisf.placementservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/placements")
public class PlacementController {

    @Autowired
    private PlacementService placementService;

    @GetMapping
    public List<Placement> getAllPlacements() {
        return placementService.getAllPlacements();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Placement> getPlacementById(@PathVariable Long id) {
    	Placement placement = placementService.getPlacementById(id);
        if (placement != null) {
            return ResponseEntity.ok(placement);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public Placement createPlacement(@RequestBody Placement placement) {
        return placementService.savePlacement(placement);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlacement(@PathVariable Long id) {
        Placement placement = placementService.getPlacementById(id);
        if (placement != null) {
            placementService.deletePlacement(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Placement> updatePlacement(@PathVariable Long id, @RequestBody Placement placementDetails) {
        Placement placement = placementService.getPlacementById(id);
        if (placement != null) {
        	placement.setId(placementDetails.getId());
        	placement.setStudent(placementDetails.getStudent());
        	placement.setCompany(placementDetails.getCompany());
        	placement.setPosition(placementDetails.getPosition());
        	Placement updatedPlacement = placementService.savePlacement(placement);
            return ResponseEntity.ok(updatedPlacement);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
