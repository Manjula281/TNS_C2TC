package com.tnisf.placementservice;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "\"placement\"") 
public class Placement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String student;
    private String company;
    private String position;
    public Placement() {
        super();
    }
	public Placement(Long id, String studentName, String companyName, String position, int placementDate, String student, String company) {
		super();
		this.id = id;
		this.student = student;
		this.company = company;
		this.position = position;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStudent() {
		return student;
	}
	public void setStudent(String student) {
		this.student = student;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	@Override
	public String toString() {
		return "Placement [id=" + id + ", student=" + student + ", company=" + company + ", position="
				+ position + "]";
	}
	
}
